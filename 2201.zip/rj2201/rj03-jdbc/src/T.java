import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author JMLF
 * @date 2023-03-13
 */
public class T {
    private static final String URL = "jdbc:mysql://localhost:3306/rj2201?characterEncoding=utf-8";
    private static final String USERNAME = "root";
    private static final String PWD = "123456";


    public static void main(String[] args) {
        try {
            //ctrl + alt + v 会生成当前代码的返回内容
            //1.注册驱动
            Class.forName("com.mysql.jdbc.Driver");
            //2.获取数据库连接 通过DriverManger获取Connection连接对象
            //  2.1 url：数据库连接的地址  jdbc:mysql://ip:端口号/数据库名称
            //  2.2 username：用户名
            //  2.3 password：密码
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/rj2201?characterEncoding=utf-8",
                    "root",
                    "123456");
            //3.通过连接信息获取执行sql语句的工具 PreparedStatement
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM 学生表");
            //4.通过创建出的工具进行执行操作 会返回结果集
            ResultSet resultSet = statement.executeQuery();
            //5.结果集遍历
            while (resultSet.next()){
                System.out.println(
                        "姓名："+resultSet.getString("姓名")+
                                ",联系方式："+resultSet.getString("联系方式"));
            }
            //6.关闭资源
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
