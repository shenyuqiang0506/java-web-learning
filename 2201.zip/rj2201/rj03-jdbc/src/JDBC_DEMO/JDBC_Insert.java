package JDBC_DEMO;

import java.sql.*;

/**
 * @author JMLF
 * @date 2023-03-13
 */
public class JDBC_Insert {
    public static void main(String[] args) {
        try {
            //ctrl + alt + v 会生成当前代码的返回内容
            //1.注册驱动
            Class.forName("com.mysql.jdbc.Driver");
            //2.获取数据库连接 通过DriverManger获取Connection连接对象
            //  2.1 url：数据库连接的地址  jdbc:mysql://ip:端口号/数据库名称
            //  2.2 username：用户名
            //  2.3 password：密码
            Connection connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/rj2201?characterEncoding=utf-8",
                    "root",
                    "123456");
            //3.通过连接信息获取执行sql语句的工具 PreparedStatement
//            PreparedStatement statement = connection.prepareStatement(
//                    "INSERT INTO 学生表(姓名,年龄,联系方式) VALUES ('1','2','3')");
            //3.后续添加数据
            PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO stu(name,age,phone) VALUES (?,?,?)");
            statement.setString(1,"x");
            statement.setInt(2,5);
            statement.setString(3,"z");

            //4.通过创建出的工具进行执行  增加操作返回操作成功条数
            int i = statement.executeUpdate();
            System.out.println("执行成功："+i);
            //5.增 改 删  需要增加一个提交执行的命令
            //connection.commit();
            //6.关闭资源
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
