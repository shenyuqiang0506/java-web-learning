package JDBC_DEMO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * @author JMLF
 * @date 2023-03-13
 */
public class JDBC_Delete {
    public static void main(String[] args) {
        try {
            //需要的数据库连接信息：驱动、地址、用户名、密码
            String driver = "com.mysql.jdbc.Driver";
            String url = "jdbc:mysql://localhost:3306/rj2201?characterEncoding=utf-8";
            String user = "root";
            String pwd = "123456";
            //需要执行的sql语句  不确定值的位置可以以？替代
            String sql = "DELETE FROM stu WHERE name = ?";
            //1.注册驱动
            Class.forName(driver);
            //2.获取数据库连接
            Connection connection = DriverManager.getConnection(url,user,pwd);
            //3.通过连接得到 预编译对象（执行sql语句用）
            PreparedStatement statement = connection.prepareStatement(sql);
            //4.给之前的 sql语句字符串里的 ？ 赋值   （第几个问号，是什么值）
            statement.setString(1,"x");
            //5.通过创建出的 预编译对象 进行执行  删除的sql语句 返回操作成功条数
            int i = statement.executeUpdate();
            System.out.println("执行删除成功："+i);
            //6.关闭资源
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
