package represp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author JMLF
 * @date 2023-03-06
 */
public class User {
    private String user;
    private String pwd;

}
