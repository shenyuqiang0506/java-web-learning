let xhr = new XMLHttpRequest();

function Ajax(options) {
	xhr.open(options.method, options.url);
	xhr.send(options.data)
	// if (options.headers != undefined) {
	// 	let keys = Object.keys(options.headers)
	// 	let values = Object.values(options.headers)
	// 	for (let i = 0; i < keys.length; i++) {
	// 		xhr.setRequestHeader(keys[i], values[i])
	// 	}
	// }
	xhr.onreadystatechange = function(e) {
		if (e.currentTarget.readyState == 4) {
			if (e.currentTarget.status == 200) {
				options.success(e.currentTarget.response)
			} else {
				options.error(e.currentTarget.response)
			}
		}
	}
}
