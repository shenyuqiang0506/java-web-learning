package com.shixun.ctrl;

/**
 * @author JMLF
 * @date 2023-06-10
 */
public class IndexCtrl {
}
