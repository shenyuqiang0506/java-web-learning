package oop;

/**
 * @author JMLF
 * @date 2023-03-20
 */
public class java01Type {
    public static void main(String[] args) {
        //数据类型：8种基础数据类型，常见的 int：整数 float：浮点数 boolean：真假 true or false
        //运算符： + - * / %，< > <= >= != ,&& || !,++ --
        //int i = 0; i = i + ++i - i++;
        //选择  if else if else 条件成立执行
        //循环 while   do while    for   条件成立不断执行，条件要向着循环停止的方向执行
        //面向对象 ： 三大特性 封装 继承 多态
    }

    //方法的定义    修饰符（public private protected） 返回值类型 方法名 (参数列表) { 执行代码 }
    public void sayHello(){
        System.out.println("say hello");
    }

}
