package oop;

import java.lang.reflect.Method;

/**
 * 类库 异常处理 IO文件处理 线程
 * @author JMLF
 * @date 2023-03-20
 */
public class java03 {
    public static void main(String[] args)  {
        //运行时的异常 除数为0的异常
        //System.out.println("除数为0的异常："+1/0);
        //数组下标越界异常  当前代码没有提示错误
        //int a [] = new int[2]; // 0 1
        //System.out.println(a[3]);
        //类型转化异常
        //int i = Integer.parseInt("abcd");
        //以上就是常见的一些运行时会出现的异常信息
        //异常处理方式 try catch
        try {
            //将有可能出错的代码写在这里
            add(-1,1);
            //catch里根据猜测的情况列出可能出现的异常信息
            //catch可以写多个 将可能的异常都列出来 有点像 switch
            //如果没有匹配上 就捕获异常失败
            //也可以捕获异常的父类 Exception 但是不精准
        }catch (myexception e){
            System.out.println("嘿嘿 我自己的异常");
        }catch (/*计算异常*/ ArithmeticException e){
            System.out.println("计算异常咯");
        }catch (/*数组下标越界*/ ArrayIndexOutOfBoundsException e ){
            System.out.println("下标越界啦");
        }catch (/*捕获异常的父类*/ Exception e){
            //打印异常信息
            e.printStackTrace();
            System.out.println("按父级异常捕获");
        }finally {
            //无论异常是否发生 都要执行 通常用于资源关闭
            System.out.println("finally 要开始执行了");
        }
        System.out.println("代码继续执行");
    }

    //异常抛出
    public static int add(int a,int b) throws myexception {
        //加法器里不允许 第一个数小于0存在
        if(a < 0){
            System.out.println("我要抛出异常了");
            //可以抛出一个异常 一定需要进行异常处理
            //向外传递 当前位置无法处理异常情况了就向外界抛出
            throw new myexception();
        }
        return a+b;
    }
}
//允许自己定义异常信息
class myexception extends Exception{}










