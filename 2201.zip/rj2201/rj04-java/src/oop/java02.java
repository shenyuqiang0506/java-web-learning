package oop;

/**
 * 面向对象：封装代码，假设当前java02类是描绘学生信息的
 * @author JMLF
 * @date 2023-03-20
 */
public class java02  {
    //学生信息：姓名 年龄
    //转化为代码
//    String name;
//    int age;
//    //学生行为：吃饭 学习
//    //转化为代码
//    public void eat(String food){
//        System.out.println(this.name + " eat " + food);
//    }
//
//    public void study(){
//        System.out.println(this.name + " in study");
//    }
//    //以上就建立好一个实体类：用于描述学生
//    public static void main(String[] args) {
//        //通过类 进行对象的实例化 类名 对象名 = new 类名的构造函数()  类里有默认的无参构造（未写过构造函数的情况下）
//        java02 stu01 = new java02();
//        //数据赋值
//        stu01.name = "小红";
//        stu01.age = -20;
//        //方法调用
//        stu01.eat("大米饭");
//        stu01.study();
//    }
    //以上是面向对象的  类与对象
    //发现可以任意的赋值某个对象里的属性，存在一些问题
    //封装：属性私有化  公开的get 与 set 接口（方法）
    //封装之后 其他类里没有办法通过 对象.属性名的方式对属性进行修改与获取
    private String name;
    private int age;
    //公开的方法可以使用属性
    public int getAge(){
        return age;
    }
    //公开的方法里可以设置一下过滤的
    public void setAge(int age){
        if(age < 0){
            System.out.println("错误信息");
        }else {
            this.age = age;
        }
    }
    //继承： 类与类之间存在上下级关系 通过继承可以细分类的内容 父级里存共同的属性与方法
    //类里只有单继承 多实现   接口与接口可以多继承  因为抽象类与接口里的方法可以不进行具体代码的编写
    //通过extends关键字实现两个类之间的联系   实现接口可以通过implements关键进行实现

    public static void main(String[] args) {
        //多态 接口 对象名 = new 接口实现类();
        AnimalInterface person01 = new PersonDt();
        person01.eat();
        AnimalInterface student01 = new StudentDt();
        student01.eat();
    }
    //多态：主要的方式就是对 继承或者实现的方法进行重写  通过接口申明对象将接口具体实现类赋值给接口
}
//继承设定的类
class animal{
    public void eat(){
        System.out.println("吃东西");
    }
}
class person extends animal{ }
//多态：方法的重载  将父类的eat方法进行重新的定义
class student extends animal{
    public void eat(){
        System.out.println("学生在吃东西");
    }
}
//多态：接口
interface AnimalInterface{
    public void eat();
}
//实现类PersonDt里实现了接口
class PersonDt implements AnimalInterface{
    @Override
    public void eat() {
        System.out.println("PersonDt重写AnimalInterface的eat接口方法");
    }
}
class StudentDt implements AnimalInterface{
    @Override
    public void eat() {
        System.out.println("StudentDt重写AnimalInterface的eat接口方法");
    }
}